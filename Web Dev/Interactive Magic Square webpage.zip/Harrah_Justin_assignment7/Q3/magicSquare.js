/********************************NOTE:****************************
*******************************************************************
****    I was uncertain how to pass the array details to my test 
****    method while avoiding use of a global variable. Because of this 
****    I chose to remove the second button and call this function as
****    part of my main function. 
********************************************************************/
// Function has been tested and array output is as expected
function InputArray(){ 
    var tempValue=0;
    var InputArray=new Array(4);
        //The if else structure is used to control program flow. The sole purpose is to ensure array 
        //data is properly passed between functions

    // create array second dimension
            for (var i=0;i<4;i++){ 

            InputArray[i] = new Array(4);
            }  
             callCount=0;
                 for(var i=0;i<4;i++){ 
                    for(var j=0;j<4;j++){  
                         InputArray[i][j]= prompt("Enter a number for row "+(i+1)+", column "+(j+1)+":");
                    }
                 }             
           // call to function to print square
             printSquare(InputArray);
             testSquare(InputArray);
             callCount+=2;
}


function printSquare(InputArray){
    var printValue=0;       
    var i=0;
     // output selected numbers into grid 
        //to acquire row/col details and print
            while(i<16){
                for(var countR=0;countR<4;countR++){  
                    for(var countC=0;countC<4;countC++){  
                      printValue=InputArray[countR][countC];
                      document.getElementById(i).innerHTML= printValue; 
                      i++;
                   }
                }
            }
        
}



function testSquare(InputArray){ 
     //document.write(InputArray[3][0]);
   /* */
    var magic=true;
	var sumDiagonal1 = parseInt(InputArray[0][0]) + parseInt(InputArray[1][1]) + parseInt(InputArray[2][2]) + parseInt( InputArray[3][3]);
	var sumDiagonal2 = parseInt(InputArray[3][0]) + parseInt(InputArray[2][1]) + parseInt(InputArray[1][2]) + parseInt( InputArray[0][3]);

		for (var i = 0; i < 4; i++ ){
			var sumR = parseInt(InputArray[i][0]) + parseInt(InputArray[i][1]) + parseInt(InputArray[i][2]) + parseInt(InputArray[i][3]);
			if (sumR != sumDiagonal1){
				magic = false;}
            }
 
		for (var j = 0; j < 4; j++ ) { 
            var sumC = parseInt(InputArray[0][j]) + parseInt(InputArray[1][j]) + parseInt(InputArray[2][j]) + parseInt( InputArray[3][j]); 
            if (sumC != sumDiagonal1)
                { magic = false; }
            }
       
        if (sumDiagonal1 != sumDiagonal2)
           {magic = false;}
     
        if (magic == false)
        {
        document.getElementById("results").innerHTML = (" Sorry, your numbers do not make a magic square");
        }
        else if(magic == true)
        { document.getElementById("results").innerHTML = (" Congratulations, Your numbers do make a magic square!!");} 
}