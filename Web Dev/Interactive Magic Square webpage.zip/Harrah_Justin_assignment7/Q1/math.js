function math(){ 
   
        var x = -1; 
        var y = -1;
        // this is used to prompt for proper input
        var count=1; 

        //variables to capture function returned values 
        var expCalc;
        var areaCalc;
        var distCalc;

            // by setting these values to neg 1 I force the loop to start, thus prompting for the proper values and checking input
            // loop continues while either x or y are not pos
            while(x < 0 || y < 0 ) { 
                x= parseInt(prompt("Enter a number for value of x.")); 
                y= parseInt(prompt("Enter a number for value of y.")); 
                if(count>1)
                   { alert("The numbers entered must be positive."); }
                count++;
             }
        //additional function calls to complete needed calculations
        expCalc = exponent(x,y);
        areaCalc= area(x,y); 
        distCalc= distance(x,y); 

        // display x and y values used for each function  
        document.getElementById("NumInput").innerHTML=("<p>Justin's first number ="+ x + "</p>");
        document.getElementById("NumInput").innerHTML= document.getElementById("NumInput").innerHTML+"<p>Justin's second number ="+ y + "</p>";  

        //display the result of the exponential multiplication 
        var stringY=y.toString();
        document.getElementById("Exponent").innerHTML=("<p>"+x+ stringY.sup()+"="+expCalc.toFixed(2)+"</p>");

        //display the result of the area calculation 
         document.getElementById("Area").innerHTML=("<p> The area of a right triangle with a base of "+x +" and a height of "+y+" = "+areaCalc.toFixed(2)+"</p>");

        //display distance formula output 
        document.getElementById("Distance").innerHTML=("<p> The distance between two points ("+x+","+y+") and (0,0) = "+ distCalc.toFixed(2)+"</p>"); 

} 

function exponent(base,power)
{  return Math.pow(base,power);}

// area= 1/2 x base x height 
function area(base,height)
{ return .5 * base * height; }

//distance = √ (x2-x1)^2 x (y2-y1)^2    where (0,0) represents x2 and y2
function distance(x1,y1)
{ return Math.sqrt(Math.pow((0-x1),2) + Math.pow((0-y1),2));}