function purchase(){ 
    // output display ctrl var 
    var purchCount=1;
    var outputLines=0;  
    var repeatPurch;

    // read in array values  
     var ItemID= Item(0); 
     var itemlist= Item(1); 
     var priceList= Item(2);  
     var output=Item(3);

    // gather user inputs
    var item; 
    var cost; 
    var NumRequested=0; 
    var userSelection=-1;
    // reports calculated cost based on cost * num requested 
    var totalCostNumRequested; 

    //bool loop control
    var newPurchase= true; 



    do{ 
         userSelection= parseInt(prompt("Enter the number that corresponds with the item you want to buy."));
            //input validation
            while(userSelection>4){ 
                alert("Please enter a value between one(1) and four(4) to continue.");
                userSelection= parseInt(prompt("Enter the number that corresponds with the item you want to buy."));
            }
         // load values from array-- minus one used to ensure elements are accessed properly    
         item=itemlist[userSelection-1];
         cost=priceList[userSelection-1]

         NumRequested= parseInt(prompt("How Many of these do you want?")); 

          totalCostNumRequested= cost * NumRequested;
        //output generation 
        
          for(var i=0; i<output.length;i++){
                  if(purchCount==1){
                   document.getElementById("PurchaseSelect1").innerHTML= document.getElementById("PurchaseSelect1").innerHTML+"<p>"+ output[i]+item+"</p>";
                   document.getElementById("PurchaseSelect1").innerHTML= document.getElementById("PurchaseSelect1").innerHTML+"<p>"+output[i+1]+"$"+ cost+" each</p>";
                   document.getElementById("PurchaseSelect1").innerHTML= document.getElementById("PurchaseSelect1").innerHTML+"<p>"+ output[i+2]+ NumRequested+"</p>";
                   document.getElementById("PurchaseSelect1").innerHTML= document.getElementById("PurchaseSelect1").innerHTML+ "<p>"+output[i+3]+totalCostNumRequested.toFixed(2) +"</p>";
                   break;      
                  }
                  
                  if(purchCount==2){
                   document.getElementById("PurchaseSelect2").innerHTML= document.getElementById("PurchaseSelect2").innerHTML+"<p>"+ output[i]+item+"</p>";
                   document.getElementById("PurchaseSelect2").innerHTML= document.getElementById("PurchaseSelect2").innerHTML+"<p>"+ output[i+1]+"$"+cost+" each</p>";
                   document.getElementById("PurchaseSelect2").innerHTML= document.getElementById("PurchaseSelect2").innerHTML+ "<p>"+output[i+2]+ NumRequested+"</p>";
                   document.getElementById("PurchaseSelect2").innerHTML= document.getElementById("PurchaseSelect2").innerHTML+"<p>"+ output[i+3]+totalCostNumRequested.toFixed(2) 
                       
                       +"</p>";
                  }
                 purchCount++; 
           } 
       
       purchCount++;  
       repeatPurch=prompt("Do you want to purchase another item? (Y/N)") ; 
       repeatPurch=repeatPurch.toUpperCase(); 
        //if this executes the do.. while structure will exit
        if (repeatPurch== "N") 
            {newPurchase=false;}
     }
    while(newPurchase==true);    


}// end function purchase


function printItems() { 
    //This function will print IDs, Item description, and price as index loads 
    var loopControl=-1; 
    var dataLineCounter=0; 

    // the following variables are pulling values from the Item function
    var itemlist= Item(1); 
    var priceList= Item(2);     
    var ItemID= Item(0);    
    // repeating the print operation until the ItemId array length is reached
    for (var i=0;i<ItemID.length;i++)
    {
        document.getElementById("ProductList").innerHTML= document.getElementById("ProductList").innerHTML+ItemID[i]+itemlist[i]+" => $"+priceList[i]; 
        document.getElementById("ProductList").innerHTML= document.getElementById("ProductList").innerHTML+"<p></p>"; 
    }

}


// this function will return array values as requested from other functions
function Item(input){ 
 
     var inputVal=input;   
     var JustinItem= new Array("Tigress action figure","Monkey action figure","Tai Lung action figure","Punching Bag action figure"); 
     var price= new Array (6,5,4,3); 
     var ItemId= new Array("1.","2.","3.","4.");
     var outputContents= new Array("Item:","Cost:","Number Requested:","Total Cost: $");

       switch (inputVal)
       { 
          case 0: 
               return ItemId; 
               break; 
           case 1: 
               return JustinItem; 
               break; 
           case 2: 
               return price;
               break; 
           case 3: 
               return outputContents;
               break;       
           default: 
               return alert("Error,invalid input");
        }
}

