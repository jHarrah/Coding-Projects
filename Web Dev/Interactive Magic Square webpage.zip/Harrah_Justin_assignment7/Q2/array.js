function array(){ 
      // below I ask the user for a indication of the number of inputs 
      // then dynamically create a new array of the required length.
      var num= parseInt(prompt("How many data values do you have?"));
      var inputArray= new Array(num);  
      
      var numSum=0;
      var inputNum;
      var mean=0; 
      var overMean=0; 
      var underMean=0;
      var tempVar=0;
      // loop to enter input into loop
      // using num minus 1 ensures I don't loop beyond array len
     for(var i=0;i<num;i++){ 
         inputNum= parseInt(prompt("Enter data value Number"+(i+1))); 
         // validation to ensure no neg input
        while (inputNum <0 ){ 
             inputNum= parseInt(prompt("Enter data value Number"+(i+1))); } 
        inputArray[i]= inputNum; 
       
         // intended to keep running sum total for mean calc 
         numSum+=inputNum;
      } 
      
      mean = numSum / num;  
       
     // if array element at j is less than or greater than mean the approprate counter is increased
     for(var j=0;j<=num; j++){ 
         if(inputArray[j] < mean)
            { underMean++; }

         if(inputArray[j] > mean )
            { overMean++;}
        }
     //output array contents   
    document.getElementById("NumInput").innerHTML=("Your data: "); 
    for(var i=0;i< num-1;i++) { 
        tempVar=inputArray[i];
        document.getElementById("NumInput").innerHTML=   document.getElementById("NumInput").innerHTML+tempVar+","; 
        } 
    // this ensures the last number does not get a comma 
    if(i=num -1)
        {document.getElementById("NumInput").innerHTML=   document.getElementById("NumInput").innerHTML+inputArray[i]; }
    
    
    document.getElementById("AVG").innerHTML= "<p> The mean (average) of this data is: "+ mean.toFixed(2); 
    document.getElementById("overmean").innerHTML= "<p>"+ overMean+ " number(s) bigger than the mean number.</p>"; 
    document.getElementById("undermean").innerHTML= "<p>"+ underMean+ " number(s) smaller than the mean number. </p>"; 

}